<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Oops!</title>
  </head>
  <body style="background-color: #3cad756c">
    <img
      style="margin: 20vh 0px 0px 47%"
      src="https://img.icons8.com/dotty/100/000000/road-worker.png"
    />
    <h1 style="color: #e84e1b; text-align: center">
      Oops! Looks like there is no data available!
    </h1>
    <h2 style="color: #e84e1b; text-align: center">See you later!</h2>
  </body>
</html>
